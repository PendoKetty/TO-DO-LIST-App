package com.example.todolist;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class login extends AppCompatActivity {
    private Button button;
    View view;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        view=this.getWindow().getDecorView();
        view.setBackgroundResource(R.color.colorblue);

        button = (Button) findViewById(R.id.login);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openTasks();
            }

        });
    }
    public void openTasks() {
        Intent intent = new Intent(this, Tasks.class);
        startActivity(intent);
    }
}
